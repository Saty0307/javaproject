import java.util.ArrayList;
import java.util.Iterator;

import com.capgemini.demo.Employee;

public class TestayyListEmpDemo 
{

	public TestayyListEmpDemo() 
	{
		
	}
	
	public static void main(String[] args) 
	{
		ArrayList<Employee> empList = new ArrayList<Employee>();
		
		Employee e1 = new Employee(157904,"Satyam",9999.0F);
		Employee e2 = new Employee(157905,"Saty",1999.0F);
		Employee e3 = new Employee(157906,"Sat",9299.0F);
		Employee e4 = new Employee(157907,"Satu",9599.0F);
		
		empList.add(e1);
		empList.add(e2);
		empList.add(e3);
		empList.add(e4);
		
		Iterator<Employee> itEmp = empList.iterator();
		while (itEmp.hasNext())
		{
			System.out.println("...."+ itEmp.next());
		}
	}

	
}
