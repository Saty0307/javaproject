
import java.util.HashSet;
import java.util.Iterator;

public class TestHashSetDemo {

	public TestHashSetDemo() 
	{
		
	}

	public static void main(String[] args) 
	{
HashSet<Integer> intSet = new HashSet<Integer>(4);
		
		Integer i1 = new Integer(40);
		Integer i2 = new Integer(10);
		Integer i3 = new Integer(30);
		Integer i4 = new Integer(30);
		
		
		intSet.add(i1);
		intSet.add(i2);
		intSet.add(i3);
		intSet.add(i4);
		
		Iterator<Integer> it= intSet.iterator();
		
		while(it.hasNext())
		{
			Integer ii=it.next();
			System.out.println("Entry : " + ii);
		}

	}

}
