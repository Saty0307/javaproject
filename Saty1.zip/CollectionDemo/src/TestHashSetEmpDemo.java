
import java.util.HashSet;
import java.util.Iterator;

import com.capgemini.demo.Employee;

public class TestHashSetEmpDemo
{

	public TestHashSetEmpDemo() 
	{
		
	}
	
	public static void main(String[] args) 
	{
		HashSet<Employee> empSet = new HashSet<Employee>();
		
		Employee e1 = new Employee(157904,"Satyam",9999.0F);
		Employee e2 = new Employee(157905,"Saty",1999.0F);
		Employee e3 = new Employee(157906,"Sat",9299.0F);
		Employee e4 = new Employee(157907,"Satu",9599.0F);
		Employee e5 = new Employee(157906,"Sat",9299.0F);
		
		
		empSet.add(e1);
		empSet.add(e2);
		empSet.add(e3);
		empSet.add(e4);
		empSet.add(e5);
		
		
		Iterator<Employee> itEmp = empSet.iterator();
		while (itEmp.hasNext())
		{
			System.out.println("...."+ itEmp.next());
		}
	}
}
