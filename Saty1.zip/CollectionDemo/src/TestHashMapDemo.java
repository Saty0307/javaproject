import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.Iterator;


public class TestHashMapDemo {

	public static void main(String[] args) 
	{
		HashMap<Long,String> directory = new HashMap<Long,String>();
	
		directory.put(31136154564L, "Satyam");
		directory.put(34566156456L, "Jerry");
		directory.put(31462156541L, "Jose");
		directory.put(31465153212L, "Tom");
		directory.put(31133551351L, "Sharma");
		directory.put(31136542121L, "Kashmiri");
		
		System.out.println(directory);
		System.out.println("********Print Entries*********");
		
		Set<Map.Entry<Long,String>> mapSet = directory.entrySet();
		
		Iterator<Map.Entry<Long,String>> it = mapSet.iterator();
		
		while(it.hasNext())
		{
			
			Map.Entry<Long,String> entry = it.next();
			System.out.println("Key :"+ entry.getKey()+ "Name :" + entry.getValue());
		}
		
		System.out.println("Print keys");
		
		Set<Long> kset =directory.keySet();
		Iterator<Long> itk = kset.iterator();
		
		while(itk.hasNext())
		{
			Long Key =itk.next();
			System.out.println(" : " + Key);
		}
		
System.out.println("Print Values");
		
		Collection<String> vset =directory.values();
		Iterator<String> itv = vset.iterator();
		
		while(itv.hasNext())
		{
			String value =itv.next();
			System.out.println(" : " + value);
		}
	}
}
