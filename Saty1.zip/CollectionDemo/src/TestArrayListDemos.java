import java.util.ArrayList;
import java.util.Iterator;

public class TestArrayListDemos 
{
	//GENERIC TYPE
	public TestArrayListDemos() 
	{
		
	}
	public static void main(String[] args) 
	{
		ArrayList<Integer> intList = new ArrayList<Integer>(4);
		
		Integer i1 = new Integer(40);
		Integer i2 = new Integer(10);
		Integer i3 = new Integer(30);
		Integer i4 = new Integer(60);
		
		
		intList.add(i1);
		intList.add(i2);
		intList.add(i3);
		intList.add(i4);
		
		Iterator<Integer> it= intList.iterator();
		
		while(it.hasNext())
		{
			Integer ii=it.next();
			System.out.println("Entry : " + ii);
		}
		
		
		
		
		
	}
}
