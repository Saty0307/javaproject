
import java.util.Iterator;
import java.util.TreeSet;

public class TestTreeSetDemo 
{

	public TestTreeSetDemo() 
	{
		
	}
	
	public static void main(String[] args) 
	{
TreeSet<Integer> intSet = new TreeSet<Integer>();
		
		Integer i1 = new Integer(40);
		Integer i2 = new Integer(10);
		Integer i3 = new Integer(30);
		Integer i4 = new Integer(30);
		
		
		intSet.add(i1);
		intSet.add(i2);
		intSet.add(i3);
		intSet.add(i4);
		
		Iterator<Integer> it= intSet.iterator();
		
		while(it.hasNext())
		{
			Integer ii=it.next();
			System.out.println("Entry : " + ii);
		}

	}
}
