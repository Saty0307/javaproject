package com.cg.mps.dto;

import java.sql.Date;

public class PurchaseDetails 
{
	int purchaseId;
	String cus_name;
	String cus_pnum;
	String cus_mail;
	Date p_date;
	int mid;
	
	public PurchaseDetails()
	{
		super();
	}
	
	
	public PurchaseDetails(int purchaseId, String cus_name, String cus_pnum, 
			String cus_mail, Date p_date, int mid) 
	{
		super();
		this.purchaseId = purchaseId;
		this.cus_name = cus_name;
		this.cus_pnum = cus_pnum;
		this.cus_mail = cus_mail;
		this.p_date = p_date;
		this.mid = mid;
	}


	public int getPurchaseId() {
		return purchaseId;
	}


	public void setPurchaseId(int purchaseId) {
		this.purchaseId = purchaseId;
	}


	public String getCus_name() {
		return cus_name;
	}


	public void setCus_name(String cus_name) {
		this.cus_name = cus_name;
	}


	public String getCus_pnum() {
		return cus_pnum;
	}


	public void setCus_pnum(String cus_pnum) {
		this.cus_pnum = cus_pnum;
	}


	public String getCus_mail() {
		return cus_mail;
	}


	public void setCus_mail(String cus_mail) {
		this.cus_mail = cus_mail;
	}


	public Date getP_date() {
		return p_date;
	}


	public void setP_date(Date p_date) {
		this.p_date = p_date;
	}


	public int getMid() {
		return mid;
	}


	public void setMid(int mid) {
		this.mid = mid;
	}


	@Override
	public String toString() {
		return "PurchaseDetails [purchaseId=" + purchaseId + ", cus_name=" + cus_name + ", Cus_pnum=" + cus_pnum
				+ ", cus_mail=" + cus_mail + ", p_date=" + p_date + ", mid=" + mid + "]";
	}
	
}
