package com.cg.mps.dto;

public class mobile 
{
	private int mid;
	private String mname;
	private int price;
	private String mqauntity;
	
	public mobile()
	{
		super();
	}
	
	public mobile(int  mid, String mname, int price, String mquantity) 
	{
		super();
		this.mid = mid;
		this.mname = mname;
		this.price = price;
		this.mqauntity= mquantity;
	}
	
	public int getMid() {
		return mid;
	}
	public void setMid(int mid) {
		this.mid = mid;
	}
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getMquantity() {
		return mqauntity;
	}
	public void setMquantity(String mquantity) {
		this.mqauntity = mquantity;
	}
	@Override
	public String toString() {
		return "mobile [mid=" + mid + ", mname=" + mname + ", price=" + price + ", mquantity=" + mqauntity + "]";
	}
	
}
