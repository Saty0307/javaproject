package com.cg.mps.dao;

import java.util.ArrayList;

import com.cg.mps.dto.mobile;
import com.cg.mps.exception.mobileException;

public interface MobDao 
{
	public ArrayList<mobile> getAllMob() throws mobileException;

	public int addmob(mobile me) throws mobileException;
	
	public int delmob(int midd) throws mobileException;
	
	public int srchmob(int sal1,int sal2) throws mobileException;
	
}
