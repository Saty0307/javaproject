package com.cg.mps.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import com.cg.mps.dto.PurchaseDetails;
import com.cg.mps.exception.PrchseDtException;

import com.cg.mps.util.Dbutil;

public class PurchaseDetailsDaoImpl implements PurchaseDetailsDao
{
	Connection con=null;
	Statement st= null;
	PreparedStatement pst = null;
	ResultSet rs=null;
	
	@Override
	public ArrayList<PurchaseDetails> getAllCusDetails() throws PrchseDtException 
	{
		
		ArrayList<PurchaseDetails> empList=new ArrayList<PurchaseDetails>();
		try 
		{
			con=Dbutil.getConn();
			String selectqry="SELECT * FROM purchasedetails";
			st=con.createStatement();
			rs=st.executeQuery(selectqry);
			while(rs.next())
			{
				empList.add(new PurchaseDetails(rs.getInt("purchaseid"),rs.getString("cname"),
						rs.getString("mailid"),rs.getString("phoneno"),rs.getDate("purchasedate")
						,rs.getInt("mobileid")));
			}
		}
		catch(Exception e)
		{
			
			throw new PrchseDtException(e.getMessage());
		}
		finally 
		{
			try
			{
				st.close();
				rs.close();
				con.close();
			}
			catch(SQLException e)
			{
				throw  new PrchseDtException(e.getMessage());
			}
		}
		
		return empList;
	}

	@Override
	public int addCus(PurchaseDetails pe) throws PrchseDtException 
	{
		int data;

		try 
		{
			con=Dbutil.getConn();
			String insertQry="INSERT INTO PURCHASEDETAILS VALUES(seq_pid.nextval,?,?,?,?,?)";
			pst=con.prepareStatement(insertQry);
			//pst.setInt(1,pe.getPurchaseId());
			pst.setString(1,pe.getCus_name());
			pst.setString(2,pe.getCus_pnum());
			pst.setString(3,pe.getCus_mail());
			pst.setDate(4, pe.getP_date());
			pst.setInt(5,pe.getMid());
			data=pst.executeUpdate();
		} 
		catch (Exception e) 
		{

			e.printStackTrace();
			throw new PrchseDtException(e.getMessage());
		} 
		return data;
		
	}

	@Override
	public int updatequant(PurchaseDetails uq) throws PrchseDtException 
	{
		
		int data;

		try 
		{
			con=Dbutil.getConn();
			String insertQry="Update mobiles set quantity=quantity-1 where MOBILEID=?";
			pst=con.prepareStatement(insertQry);
			pst.setInt(1,uq.getMid());
			data=pst.executeUpdate();
		} 
		catch (Exception e) 
		{

			e.printStackTrace();
			throw new PrchseDtException(e.getMessage());
		} 
		return data;
	}

}
