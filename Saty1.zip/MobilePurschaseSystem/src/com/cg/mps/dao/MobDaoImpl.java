package com.cg.mps.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Logger;

import org.apache.log4j.PropertyConfigurator;

import com.cg.mps.dto.mobile;
import com.cg.mps.exception.mobileException;
import com.cg.mps.util.Dbutil;

public class MobDaoImpl implements MobDao
{

	Connection con=null;
	Logger daoLogger =null;
	Statement st= null;
	PreparedStatement pst = null;
	ResultSet rs=null;
	public MobDaoImpl()
	{
		//daoLogger=Logger.getLogger(MobDaoImpl.class);  
		PropertyConfigurator.configure("Resource/log4j.properties");
	}
	@Override
	public ArrayList<mobile> getAllMob() throws mobileException 
	{
		ArrayList<mobile> empList=new ArrayList<mobile>();
		try 
		{
			con=Dbutil.getConn();
			String selectqry="SELECT * FROM mobiles WHERE QUANTITY>0";
			st=con.createStatement();
			rs=st.executeQuery(selectqry);
			while(rs.next())
			{
				empList.add(new mobile(rs.getInt("MOBILEID"),rs.getString("NAME"),
						rs.getInt("PRICE"),rs.getString("QUANTITY")));
				//System.out.println(rs.getString("QUANTITY"));
			}
		}
		catch(Exception e)
		{
			//daoLogger.error(e.getMessage());
			throw new mobileException(e.getMessage());
		}
		finally 
		{
			try
			{
				st.close();
				rs.close();
				con.close();
			}
			catch(SQLException e)
			{
				throw  new mobileException(e.getMessage());
			}
		}
		//daoLogger.info("All data retrived" + empList);
		return empList;

	}

	@Override
	public int addmob(mobile me) throws mobileException
	{
		int data;

		try 
		{
			con=Dbutil.getConn();
			String insertQry="INSERT INTO mobiles VALUES(?,?,?,?)";
			pst=con.prepareStatement(insertQry);
			pst.setInt(1,me.getMid());
			pst.setString(2,me.getMname());
			pst.setInt(3,me.getPrice());
			pst.setString(4,me.getMquantity());
			data=pst.executeUpdate();
		} 
		catch (Exception e) 
		{

			e.printStackTrace();
			throw new mobileException(e.getMessage());
		} 
		return data;
	}
	@Override
	public int delmob(int midd) throws mobileException 
	{
		int data;

		try 
		{
			con=Dbutil.getConn();
			String Query ="DELETE FROM  mobiles WHERE MOBILEID=?";
			pst=con.prepareStatement(Query);
			pst.setInt(1,midd);
			data=pst.executeUpdate();
		} 
		catch (Exception e) 
		{

			e.printStackTrace();
			throw new mobileException(e.getMessage());
		} 
		return data;
	}
	@Override
	public int srchmob(int sal1,int sal2) throws mobileException 
	{
		
		int data;
		Scanner sc=new Scanner(System.in);
		try 
		{
			con=Dbutil.getConn();
			String Query ="SELECT * FROM  mobiles WHERE PRICE>=? AND PRICE<=?";
			pst=con.prepareStatement(Query);
			pst.setInt(1,sal1);
			pst.setInt(2,sal2);
			data =pst.executeUpdate();
			rs=pst.executeQuery();
			System.out.println("\tMobileId \tMobileName \t MobilePrice\t Quantity");
			while(rs.next())
			{
					System.out.println("\t" +rs.getInt("MOBILEID")+ "\t" + rs.getString("NAME")
					+ "\t" + rs.getInt("PRICE") + "\t" + rs.getString("QUANTITY"));
			}
			
		} 
		catch (Exception e) 
		{

			e.printStackTrace();
			throw new mobileException(e.getMessage());
		}
		return data; 
	}
}


