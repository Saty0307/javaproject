package com.cg.mps.dao;

import java.util.ArrayList;

import com.cg.mps.dto.PurchaseDetails;
import com.cg.mps.exception.PrchseDtException;

public interface PurchaseDetailsDao 
{
	public ArrayList<PurchaseDetails> getAllCusDetails() throws PrchseDtException;

	public int addCus(PurchaseDetails pe) throws PrchseDtException;
	
	public int updatequant(PurchaseDetails uq) throws PrchseDtException;
}
