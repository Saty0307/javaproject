package com.cg.mps.service;

import java.util.ArrayList;

import com.cg.mps.dto.PurchaseDetails;
import com.cg.mps.dto.mobile;
import com.cg.mps.exception.PrchseDtException;
import com.cg.mps.exception.mobileException;

public interface Services 
{
	public ArrayList<mobile> getAllMob() throws mobileException;

	public int addmob(mobile m1) throws mobileException;
	
	public int delmob(int midd) throws mobileException;
	
	public int srchmob(int sal1, int sal2) throws mobileException;
	
	public ArrayList<PurchaseDetails> getAllCusDetails() throws PrchseDtException;

	public int addCus(PurchaseDetails pe) throws PrchseDtException;
	
	public int updatequant(PurchaseDetails uq) throws PrchseDtException;
	
	public boolean validateCusName(String cName) throws PrchseDtException;
	
	public boolean validateQuantity(int Mid) throws mobileException;
	
	public boolean validateNumber(String pNum) throws PrchseDtException;
	
	public boolean validateMid(int mid) throws mobileException;
	
	public boolean validatecMail(String CMail) throws PrchseDtException;

	
	
}
