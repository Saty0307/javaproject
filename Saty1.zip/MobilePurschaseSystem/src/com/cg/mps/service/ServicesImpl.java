package com.cg.mps.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.regex.Pattern;


import com.cg.mps.dao.MobDaoImpl;
import com.cg.mps.dao.PurchaseDetailsDaoImpl;
import com.cg.mps.dto.PurchaseDetails;
import com.cg.mps.dto.mobile;
import com.cg.mps.exception.PrchseDtException;
import com.cg.mps.exception.mobileException;
import com.cg.mps.util.Dbutil;

public class ServicesImpl implements Services
{
	MobDaoImpl mdi=null;
	Connection con=null;
	Statement st= null;
	PreparedStatement pst = null;
	ResultSet rs=null;
	PurchaseDetailsDaoImpl pdi= null;
	public ServicesImpl()
	{
		mdi = new MobDaoImpl();
		pdi = new PurchaseDetailsDaoImpl();
	}
	@Override
	public ArrayList<mobile> getAllMob() throws mobileException 
	{
		
		return mdi.getAllMob();
	}

	@Override
	public int addmob(mobile m1) throws mobileException
	{
		return mdi.addmob(m1);
	}

	@Override
	public int delmob(int midd) throws mobileException 
	{
		
		return mdi.delmob(midd);
	}

	@Override
	public int srchmob(int sal1,int sal2) throws mobileException 
	{
		
		return mdi.srchmob(sal1,sal2);
	}

	@Override
	public ArrayList<PurchaseDetails> getAllCusDetails() throws PrchseDtException 
	{
		
		return pdi.getAllCusDetails();
	}

	@Override
	public int addCus(PurchaseDetails pe) throws PrchseDtException 
	{
		
		return pdi.addCus(pe);
	}

	@Override
	public int updatequant(PurchaseDetails uq) throws PrchseDtException 
	{
		
		return pdi.updatequant(uq);
	}
	
	
	@Override
	public boolean validateCusName(String cName) throws PrchseDtException 
	{
		
		String namePattern = "[A-Z][a-z]{1,20}";
		if(Pattern.matches(namePattern, cName))
		{
			return true;
		}
		else
		{
			throw new PrchseDtException("Invalid Name :"
					+ "Should start with capital letter ");
		}
	}
	
	
	@Override
	public boolean validateQuantity(int mid) throws mobileException 
	{
		
		int data;
		String quant = null;
		try 
		{
			con=Dbutil.getConn();
			String Qry="SELECT QUANTITY  FROM MOBILES where MOBILEID="+ mid;
			st=con.createStatement();
			rs=st.executeQuery(Qry);
			while(rs.next())
			{
			quant=rs.getString("Quantity");
			}
		}
		catch (Exception e) 
		{

			e.printStackTrace();
			throw new mobileException(e.getMessage());
		} 
		if(quant=="0")
		{
			throw new mobileException("Mobile is out of stock");
		}
		else
		{
			return true;
		}
	}
	
	
	@Override
	public boolean validateNumber(String pNum) throws PrchseDtException 
	{
		String phonepattern= "[0-9]{10}";
		if(Pattern.matches(phonepattern, pNum))
		{
			return true;
		}
		else
		{
		throw new PrchseDtException("Enter 10 digit Number");
		}
	}
	
	
	
	@Override
	public boolean validateMid(int mid) throws mobileException 
	{	boolean b;
		try 
		{
			con=Dbutil.getConn();
			String Qry="SELECT * FROM MOBILES where MOBILEID="+ mid;
			st=con.createStatement();
			rs=st.executeQuery(Qry);
			b=rs.next();
		}
		catch (Exception e) 
		{

			e.printStackTrace();
			throw new mobileException(e.getMessage());
		} 
		if(b) 
		{
			
			return true;
			
		}
		else 
		{	
			throw new mobileException("There is no mobile with such id");
		}
	}
	
	
	
	
	@Override
	public boolean validatecMail(String CMail) throws PrchseDtException 
	{
		String phonepattern= "[A-Za-z0-9._%+-]+@[A-Za-z]+[.][A-Za-z]{1,3}";
		if(Pattern.matches(phonepattern, CMail))
		{
			return true;
		}
		else
		{
		throw new PrchseDtException("Enter a valid Mail ID!");
		}
	}	
}
