package com.cg.mps.Junit;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.cg.mps.dto.mobile;
import com.cg.mps.exception.mobileException;
import com.cg.mps.service.ServicesImpl;




public class TestCaseMPS 
{
	@Test
	public void testaddMobile()
	{
		mobile mo = new mobile(1007,"MI Note 3",14000,"10");
		ServicesImpl se= new ServicesImpl();
		try 
		{
			int a=se.addmob(mo);
			assertEquals(1,a);
		} 
		catch (mobileException e) 
		{
			e.printStackTrace();
		}
		
	}
	
	@Test
	public void testSearchMobile()
	{
		mobile mo = new mobile();
		ServicesImpl se= new ServicesImpl();
		try 
		{
			int a=se.srchmob(15000,20000);
			assertEquals(2,a);
		} 
		catch (mobileException e) 
		{
			e.printStackTrace();
		}
		
	}
}
