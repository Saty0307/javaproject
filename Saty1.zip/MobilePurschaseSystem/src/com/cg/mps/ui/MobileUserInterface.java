package com.cg.mps.ui;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;
import com.cg.mps.dto.PurchaseDetails;
import com.cg.mps.dto.mobile;
import com.cg.mps.exception.PrchseDtException;
import com.cg.mps.exception.mobileException;
import com.cg.mps.service.Services;
import com.cg.mps.service.ServicesImpl;



public class MobileUserInterface 
{
	static Services service=null;
	static Scanner sc= null;
	public static void main(String[] args) 
	{
		sc=new Scanner(System.in);
		service = new ServicesImpl();

		System.out.println("*******Welcome to MPS*******");

		while(true)
		{
			System.out.println("What do you want to do?");
			System.out.println("\t 1: Add mobile\t 2 : Add Purchase date 3 : Show all Mobiles\n"
					+ "\t 4 : Delete Mobile\t 5 : Search for Mobile\n" 
					+"\t 6: EXIT " );
			System.out.println("Enter your Choice");
			int Choice=sc.nextInt();
			switch(Choice)
			{
			case 1: AddMobile();break;
			case 2: AddPurhaseDate();break;
			case 3: DisplayMob();break;
			case 4:	DelMob();break;
			case 5:	SearchMob();break;
			default: System.exit(1);
			}
		}

	}

	private static void SearchMob() 
	{
		try 
		{
			System.out.println("Enter your price range");
			System.out.println("Price From :");
			int sal1=sc.nextInt();
			System.out.println("Price To :");
			int sal2=sc.nextInt();
			service.srchmob(sal1,sal2);
		}
		catch(mobileException e)
		{
			e.printStackTrace();
		}
	}
	private static void DelMob() 
	{
		System.out.println("Enter the mobile Id");
		int middel=sc.nextInt();
		try {
			int c=service.delmob(middel);
			if(c==1)
			{
				System.out.println("Mobile Deleted Succesfully");
			}
			else
			{
				System.out.println("Mobile Deleting 'FAILED'");
			}
		} 
		catch (mobileException e) 
		{
			e.printStackTrace();
		}


	}
	private static void DisplayMob() 
	{
		ArrayList<mobile> empList;
		try
		{
			empList= service.getAllMob();

			System.out.println("\tMobileId \tMobileName \t MobilePrice\t Quantity");
			for(mobile me:empList)
			{
				System.out.println("\t"+me.getMid()+"\t"+ me.getMname() + "\t" + me.getPrice() + "\t" +me.getMquantity());

			}
		}
		catch(mobileException e)
		{
			e.printStackTrace();
		}

	}
	private static void AddPurhaseDate() 
	{
		try
		{
			System.out.println("Enter Mobile id");
			int mn= sc.nextInt();
			if(service.validateMid(mn))
			{
				if(service.validateQuantity(mn))
				{
					System.out.println("Enter name");
					String cnm= sc.next();
					if(service.validateCusName(cnm))
					{
						System.out.println("Enter Mail ID");
						String cmail= sc.next();
						if(service.validatecMail(cmail));
						{
							System.out.println("Enter Phone Number");
							String cphnum= sc.next();
							if(service.validateNumber(cphnum));
							{
								Date mpd = Date.valueOf(LocalDate.now());
								PurchaseDetails p1= new PurchaseDetails(1,cnm,cmail,cphnum,mpd,mn);
								int dataInserted = service.addCus(p1);
								if(dataInserted==1)
								{
									UpdateQunatity(p1);
									dispdate();
									System.out.println("Data is Successfully Inserted");
								}
								else
								{
									System.out.println("SORRY! Data is not Inserted");
								}
							}
						}
						
					}
				}
			}
		}
			catch(PrchseDtException | mobileException e)
			{
				e.printStackTrace();
			}
	}

	private static void dispdate() 
	{
		ArrayList<PurchaseDetails> empList;
		try
		{
			empList= service.getAllCusDetails();

			System.out.println("\tPurchase Id \tCustomerName \t Customer Phone number"
					+ "\t Customer Mail" + "\t Date" + "\t Mobile id");
			for(PurchaseDetails pd:empList)
			{
				System.out.println("\t"+pd.getPurchaseId()+"\t" +
						pd.getCus_name() + "\t" + pd.getCus_pnum() + "\t" +pd.getCus_mail()
						+"\t" +  pd.getP_date() + "\t" + pd.getMid());

			}
		}
		catch(PrchseDtException e)
		{
			e.printStackTrace();
		}

	}

	private static void UpdateQunatity(PurchaseDetails p1) 
	{
		try 
		{
			service.updatequant(p1);
		} 
		catch (PrchseDtException e) 
		{
			e.printStackTrace();
		}
	}
	private static void AddMobile() 
	{
		try
		{
			System.out.println("Enter mobile ID");
			int mid=sc.nextInt();
			sc.nextLine();
			System.out.println("Enter name");
			String mnm= sc.nextLine();
			System.out.println("Enter Price");
			int mprice= sc.nextInt();
			sc.nextLine();
			System.out.println("Enter Quantity");
			String quant= sc.nextLine();
			mobile m1=new mobile(mid,mnm,mprice,quant);
			int c=service.addmob(m1);
			if(c==1)
			{
				System.out.println("Mobile Added Succesfully");
			}
			else
			{
				System.out.println("Mobile Adding 'FAILED'");
			}
		}
		catch(mobileException e)
		{
			e.printStackTrace();
		}

	}

}

