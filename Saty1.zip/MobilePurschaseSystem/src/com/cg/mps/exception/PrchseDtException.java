package com.cg.mps.exception;

public class PrchseDtException extends Exception
{
String msg; 
	
	public PrchseDtException(String msg) 
	{
		
		super(msg);
	}
	public PrchseDtException(String msg,Throwable cause,ErrorCode code)
	{
		super(msg,cause);
	}
}
