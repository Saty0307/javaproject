package com.cg.mps.exception;


public class mobileException extends Exception
{
	String msg; 
	
	public mobileException(String msg) 
	{
		
		super(msg);
	}
	public mobileException(String msg,Throwable cause,ErrorCode code)
	{
		super(msg,cause);
	}
}
