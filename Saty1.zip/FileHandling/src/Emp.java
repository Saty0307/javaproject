import java.io.Serializable;

public class Emp implements Serializable {
	
	int empId;
	String empName;
	float empSal;
	
	public Emp()
	{
		
	}


public Emp(int empId, String empName, float empSal) 
{
	super();
	this.empId = empId;
	this.empName = empName;
	this.empSal = empSal;
}



@Override
public String toString() 
{
	return "Emp [empId=" + empId + ", empName=" + empName + ", empSal=" + empSal + "]";
}




}
