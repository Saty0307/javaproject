import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class TestFileReadLineDemo 
{

	public static void main(String[] args)
	{
		File myfile = new File("D:\\Satyam Kashmiri\\FileHandling\\src\\TestEmployeeReadDemo.java");
		FileReader fr =null;
		FileWriter fw = null;
		BufferedReader br =null;
		BufferedWriter bw = null;
		try 
		{
			 fr = new FileReader(myfile);
			 br= new BufferedReader(fr);
			 
			 fw = new FileWriter("MyFile.txt");
			 bw = new BufferedWriter(fw);
			 String line = br.readLine();
			
			 while(line!=null)
			 {
				 System.out.println(line);
				 bw.write(line);
				 bw.flush();// will write the data into file.
				 line= br.readLine();
			 }
			 System.out.println("All data is written in the file");
		} 
		catch (IOException e) 
		{
			
			e.printStackTrace();
		}
		
	}

}
