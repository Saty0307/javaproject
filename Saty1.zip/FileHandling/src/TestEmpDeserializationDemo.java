import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class TestEmpDeserializationDemo 
{
	//fetching data of object from file.
	public static void main(String[] args) 
	{	FileInputStream fis = null;
		ObjectInputStream ois = null;
		
		try 
		{
				fis = new FileInputStream("EmpObjs.obj");
				ois= new ObjectInputStream(fis);
				Emp ee= (Emp)ois.readObject(); 
				System.out.println("Emp info from File: "+ ee);	
		} 
		catch (ClassNotFoundException | IOException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
				
			
		
		

	}

}
