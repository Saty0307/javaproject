import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class TestFileReadDemo 
{
	public static void main(String[] args) 
	{
		File myfile = new File("D:\\Satyam Kashmiri\\FileHandling\\src\\TestEmployeeReadDemo.java");
		FileInputStream fis =null;
		try 
		{
			 fis = new FileInputStream(myfile);
			 int data;
			 data = fis.read();
			
			 while(data!=-1)
			 {
				 System.out.print((char)data);
				 data= fis.read();
			 }
		} 
		catch (IOException e) 
		{
			
			e.printStackTrace();
		}
		
	}
}
