package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class TestEmpSelectDemo2 
{
	public static void main(String[] args) 
	{
		Connection con= null;
		//Statement st= null;
		ResultSet rs= null;
		PreparedStatement  pst= null;
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter min sal");
		String minsal = sc.next();
		System.out.println("Enter max sal");
		String maxsal = sc.next();
		String Query ="SELECT * FROM emp_157904 where emp_name_salary>? and "
				+ "emp_name_salary>?";
	try 
	{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con = DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:ORCL11G",
					"lab1btrg33","lab1boracle");
			pst =  con.prepareStatement(Query);
			pst.setString(1,minsal);
			pst.setString(2,maxsal);
			//st= con.createStatement();
			rs=pst.executeQuery();
			while(rs.next())
			{
			System.out.println(": "+ rs.getString("emp_id") + ": "+ rs.getString("emp_name")
			+": "+ rs.getString("emp_name_salary"));
			}
	}
		catch (ClassNotFoundException |SQLException e) 
		{
			e.printStackTrace();
		}


	}
	
}
