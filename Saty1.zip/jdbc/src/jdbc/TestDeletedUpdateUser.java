package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class TestDeletedUpdateUser 
{

	public static void main(String[] args) 
	{
		Connection con = null;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter ID you want to delete");
		String id = sc.next();
		System.out.println("Enter updated Salary ");
		String sal = sc.next();
		System.out.println("Enter id where you want to update");
		String nid = sc.next();
		ResultSet rs= null;
		Statement st= null;
		PreparedStatement pst = null;
		String Query ="Update emp_157904 set emp_name_salary=? where emp_id=?";
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:ORCL11G",
						"lab1btrg33","lab1boracle");
				st= con.createStatement();
				rs=st.executeQuery("DELETE from emp_157904 where emp_id=" + id);
				System.out.println("data is deleted in the table");
				
				pst =  con.prepareStatement(Query);
				pst.setString(1,sal);
				pst.setString(2,nid);
				pst.executeUpdate();
				
				
				System.out.println("data is Updated in the table");
				
				
				
		}
			catch (ClassNotFoundException |SQLException e) 
			{
				e.printStackTrace();
			}
		
	}

}
