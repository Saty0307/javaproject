package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class TestEmployeeInsertDemo 
{

	public static void main(String[] args) 
	{
		Connection con = null;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter ID");
		String id = sc.next();
		System.out.println("Enter Name");
		String name = sc.next();
		System.out.println("Enter Salary");
		String sal = sc.next();
		String insertQry = "INSERT INTO emp_157904 values(?,?,?)";
		
		PreparedStatement pst = null;
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:ORCL11G",
						"lab1btrg33","lab1boracle");

				pst= con.prepareStatement(insertQry);
				pst.setString(1,id);
				pst.setString(2,name);
				pst.setString(3,sal);
				int noOfRecAffected = pst.executeUpdate();
				System.out.println("data is insereted in the table");
		}
			catch (ClassNotFoundException |SQLException e) 
			{
				e.printStackTrace();
			}
 	}

}
