package com.cg.ems.dto;

public class Employee 
{
	private String emp_id;
	private String empName;
	private String empSal;
	
	public Employee() 
	{
		super();
	}
	
	public Employee(String emp_id, String empName, String empSal) 
	{
		super();
		this.emp_id = emp_id;
		this.empName = empName;
		this.empSal = empSal;
	}
	public String getEmp_id() {
		return emp_id;
	}
	public void setEmp_id(String emp_id) {
		this.emp_id = emp_id;
	}
	
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpSal() {
		return empSal;
	}
	public void setEmpSal(String empSal) {
		this.empSal = empSal;
	}
	
	@Override
	public String toString() 
	{
		return "Employee [emp_id=" + emp_id + ", empName=" + empName + ", empSal=" + empSal + "]";
	}
}
