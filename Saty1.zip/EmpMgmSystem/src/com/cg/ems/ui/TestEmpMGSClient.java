package com.cg.ems.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.service.EmpService;
import com.cg.ems.service.EmpServiceImpl;

public class TestEmpMGSClient 
{
	static EmpService empService=null;
	static Scanner sc= null;
	public static void main(String[] args) 
	{
		sc=new Scanner(System.in);
		empService = new EmpServiceImpl();

		System.out.println("*******Welcome to EMS*******");

		while(true)
		{
			System.out.println("What do you want to do?");
			System.out.println("\t 1: Add Employee\t 2 : Show all emp\n"
					+ "\t 3 : Update Employee\t 4 : Delete Employee\t\n" 
					+"\t 5: EXIT " );
			System.out.println("Enter your Choice");
			int Choice=sc.nextInt();
			switch(Choice)
			{
			case 1: insertEmp();break;
			case 2: dispAllemp();break;
			default: System.exit(1);
			}
		}



	}
	private static void dispAllemp() 
	{

		ArrayList<Employee> empList;
		try
		{
			empList= empService.getAllEmp();

			System.out.println("\tEmpId \tEmpName \tEmpsal");
			for(Employee ee:empList)
			{
				System.out.println("\t"+ee.getEmp_id()+"\t" +
						ee.getEmpName() + "\t" + ee.getEmpSal());

			}
		}
		catch(EmployeeException e)
		{
			e.printStackTrace();
		}
	}
	private static void insertEmp() 
	{
		try
		{
		System.out.println("Enter your ID");
		String eid=sc.next();
		System.out.println("Enter name");
		String enm= sc.next();
		String esl="0.0";
		
		if(empService.validateEmpName(enm))
		{
			System.out.println("Enter Salary");
			esl=sc.next();
			Employee e1= new Employee(eid,enm,esl);
			int dataInserted = empService.addEmp(e1);
			if(dataInserted==1)
			{
				dispAllemp();
			}
			else
			{
				System.out.println("SORRY! Data is not Inserted");
			}
		}
		}
		catch(EmployeeException e)
		{
			e.printStackTrace();
		}
		
	}

}
