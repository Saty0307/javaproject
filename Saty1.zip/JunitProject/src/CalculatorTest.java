import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class CalculatorTest 
{
	static Calculator calc = null;

	@BeforeClass
	public static void setup()
	{
		calc = new Calculator();
		System.out.println("Setup is Call once " + "Before the execution of " +
				"all test cases" );

	}

	@AfterClass
	public static void tearDown()
	{
		System.out.println("Teardown is Call once " + "After the execution of " +
				"all test cases" );

	}

	@Before
	public  void init()
	{
		System.out.println("Init is Call once " + "Before the execution of " +
				"each test cases" );

	}

	@After
	public  void destory()
	{
		System.out.println("desotry is Call once " + "After the execution of " +
				"each test cases" );

	}

	@Test
	public void testDivide1()
	{
		Assert.assertEquals(1,calc.divide(100));
	}

	@Test
	public void testDivide2()
	{
		Assert.assertEquals(20,calc.divide(5));
	}
	
	@Test(expected=ArithmeticException.class)
	public void testDivide3()
	{
		Assert.assertEquals(1,calc.divide(0));
	}

}
