package com.cg.eis.bean;


public class SalaryException extends Exception {


	public String toString()      
	{
		return "Salary is less than 3000";
	}
	public SalaryException() 
	{
		// TODO Auto-generated constructor stub
	}

	public void check(double sal) 
	{
		Employee e1 = new Employee();
		//try
		//{
			if( sal < 3000)
			{

				throw new RuntimeException(); // done runtime bcoz we are using test cases
				//in salary in  Exception Check class.
			}
		//}
		/*catch(SalaryException e)
		{
			System.out.println(e);
		}*/
	}

	/*public static void main(String[] args) 
	{
		Employee e1 = new Employee();
		try
		{
			if( e1.getSalary() < 3000)
			{

				throw new SalaryException();
			}
		}
		catch(SalaryException e)
		{
			System.out.println(e);
		}

	}*/


}
