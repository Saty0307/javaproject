package com.cg.eis.bean;

import org.junit.Test;

public class ExceptionCheck 
{
	SalaryException se= new SalaryException();
	Employee ee = null;
	
	@Test (expected=RuntimeException.class)
	public void testSalary()
	{
		//System.out.println("Salary :" );
	
		se.check(300);
		
	}
	
	
}
