package com.capgemini.DateTime;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class time {

	public time() {
		// TODO Auto-generated constructor stub
	}
	public static void main(String[] args) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter in this format= MM/dd/yyyy");
		String input  = sc.nextLine();
		LocalDate date1 = LocalDate.parse(input,formatter);
		System.out.println(date1);
		System.out.print("Enter in this format= MM/dd/yyyy");
		String input2 = sc.nextLine();
		LocalDate date2 = LocalDate.parse(input2,formatter);
		Period p = date1.until(date2);
		System.out.println("Days= " + p.getDays());
		System.out.println("Months= "+ p.getMonths());
		System.out.println("Years= " + p.getYears());
		
	}
}

