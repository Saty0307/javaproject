package com.capgemini.DateTime;

import java.time.Month;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Scanner;

public class ZoneIdentiy 
{
	public static void zone (String z)
	{
		ZonedDateTime yourzone = ZonedDateTime.now(ZoneId.of(z));
		int year= yourzone.getYear();
	    int date= yourzone.getDayOfMonth();
		Month month = yourzone.getMonth();
		 int hour = yourzone.getHour();
		 int min = yourzone.getMinute();
		 int sec = yourzone.getSecond();
		System.out.println("Current date of : "+ z + " is " + year +" " + month.getValue()+ " " + date);
		System.out.println("Current time of : "+ z + " is " + hour+ ":" + min +":" + sec);
	}

	public ZoneIdentiy() 
	{
		
	}
	
	public static void main(String[] args) 
	{
		System.out.println("Enter your zone ID");
		Scanner sc= new Scanner(System.in);
		String zo= sc.nextLine();
		zone(zo);
		sc.close();
	}	
}
