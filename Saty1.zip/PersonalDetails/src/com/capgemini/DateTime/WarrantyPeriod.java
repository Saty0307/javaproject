package com.capgemini.DateTime;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class WarrantyPeriod {

	public WarrantyPeriod() {
		// TODO Auto-generated constructor stub
	}
	public static void main(String[] args) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter purchase date in this format= dd/MM/yyyy");
		String input  = sc.nextLine();
		LocalDate date1 = LocalDate.parse(input,formatter);
		System.out.print("Enter your waranty month and year");
		int m = sc.nextInt();
		int y = sc.nextInt();
		date1 =date1.plusMonths(m);
		date1=date1.plusYears(y);
		System.out.println(date1);
	}
}
