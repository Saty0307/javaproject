package com.capgemini.exception;

import com.capgemini.lesson9.Person;


public class NameException extends Exception 
{

	public String toString()      
	{
		return "Name is blank";
	}



	public NameException() 
	{
		
	}

	public static void main(String[] args) {
		Person p = new Person();
		try
		{
			if(p.getFname().equals("") && p.getLname().equals(""))
			{

				throw new NameException();
			}
		}
		catch(NameException e)
		{
			System.out.println(e);
		}

	}

}
