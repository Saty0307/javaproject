package com.capgemini.lesson9;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestCase 
{
	Person p = new Person("Satyam","Kashmiri",'M',"03/07/1996");
	
	@Test
	public void testFName()
	{
		System.out.println("F_Name :" + p.getFname());
		
		assertEquals("Satyam",p.getFname());
	}
	@Test
	public void testlName()
	{
		System.out.println("L_Name :" + p.getLname());
		
		assertEquals("Kashmiri",p.getLname());
	}
	@Test
	public void testG()
	{
		System.out.println("Gender :" + p.getGen());
		
		assertEquals('M',p.getGen());
	}
	@Test
	public void testDOB()
	{
		System.out.println("DOB :" + p.getDOB());
		
		assertEquals("03/07/1996",p.getDOB());
	}
	
	@Test
	public void testDetails()
	{
		System.out.println("Details :" + p.toString());
		
		assertEquals("Person [fname=Satyam, lname=Kashmiri, gen=M, DOB=03/07/1996]"
				,p.toString());
	}
	
}
