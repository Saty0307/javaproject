package com.capgemini.lesson9;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;

public class Person {
	
	 String fname;
	 String lname;
	char gen;
	String DOB;

	public String getDOB() {
		return DOB;
	}

	public void setDOB(String dOB) {
		DOB = dOB;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public char getGen() {
		return gen;
	}

	public void setGen(char gen) {
		this.gen = gen;
	}

	
	public Person() {
		// TODO Auto-generated constructor stub
		this.fname="";
		this.lname="";
		this.gen='g';
		this.DOB=" ";
	}
	
	public Person(String f,String l,char g,String d) {
		// TODO Auto-generated constructor stub
		this.fname=f;
		this.lname=l;
		this.gen=g;
		this.DOB=d;
	}
	private static int CalculateAge(String dOB2) 
	{
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate CurrentDate = LocalDate.now();
		LocalDate BirthdayDay = LocalDate.parse(dOB2,formatter);
		Period p = BirthdayDay.until(CurrentDate);
		
		 
		return p.getYears();
	}
	
	private static String getFullName(String Fn,String ln)
	{
		return Fn+ln;
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person p = new Person("Satyam","Kashmiri",'M',"03/07/1996");
		
		System.out.println("First name: " + p.getFname());
		System.out.println("Last name: " + p.getLname());
		System.out.println("Gender: " + p.getGen());
		System.out.println("Age of Person is " + CalculateAge(p.DOB));
		System.out.println("Full name of Person is " + getFullName(p.fname,p.lname));
	}

	@Override
	public String toString() {
		return "Person [fname=" + fname + ", lname=" + lname + ", gen=" + gen + ", DOB=" + DOB + "]";
	}



}
