package com.capgemini.AccountDetails;

public class Person {
	
	String name;
	float age;
	public Person() {
		// TODO Auto-generated constructor stub
		this.age=30;
		this.name="";
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public float getAge() {
		return age;
	}

	public void setAge(float age) {
		this.age = age;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person p = new Person();
		System.out.println(p.getAge());
		System.out.println(p.getName());
	}

}
