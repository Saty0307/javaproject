package com.capgemini.AccountDetails;



public class Account {
 long accNum;
 double balance;
 Person accHolder;
 
	public Account() {
		// TODO Auto-generated constructor stub
	}

	public long getAccNum() {
		return accNum;
	}

	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public Person getAccHolder() {
		return accHolder;
	}

	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}
   public void Deposit()
  {
	  
  }
   public void withdraw()
   {
	   
   }
   public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
   
}
