package com.capgemini.AccountDetails;



public class AgeException extends Exception{
	
	public String toString()      {
        return "Age is greater than 15";
     }

	public static void main(String[] args) {
	Person p = new Person();
	try
	{
		if( p.getAge() > 15)
		{
		
		throw new AgeException();
		}
	}
	catch(AgeException e)
	{
		System.out.println(e);
	}
	
	}
	public AgeException() {
		// TODO Auto-generated constructor stub
	}

}
