package com.capgemini.demo;

public class TestVarArgsDemo 
{
	public int add(int ... nums)
	{
		int sum=0;
		for(int tempNum:nums)
		{
			sum=sum+tempNum;
		}
		return(sum);
	}
	public TestVarArgsDemo() 
	{
		
	}
	
	public static void main(String[] args) 
	{
		TestVarArgsDemo obj1 = new TestVarArgsDemo();
		System.out.println("Additon of number" + obj1.add(20,30));
		System.out.println("Additon of number" + obj1.add(2,5,30,4));
		
	}

}
