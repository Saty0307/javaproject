package com.capgemini.demo;

import java.util.Scanner;

public class TestingArray 
{
	

	public TestingArray() 
	{
		
	}
	
	public static void main(String[] args) 
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter no. of elments");
		int count=sc.nextInt();
		Employee emps[] = new Employee[count];
		
		for(int i=0;i<emps.length;i++)
		{
			System.out.println("Enter Id");
			int a=sc.nextInt();
			System.out.println("Enter your name");
			String n=sc.next();
			System.out.println("Enter your salary");
			float f = sc.nextFloat();
			emps[i]= new Employee(a,n,f);
		}
		
		for(int i=0;i<emps.length;i++)
		{
			System.out.println(emps[i]);
		}
	}

}
