package FileIO;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;

import com.cg.eis.bean.Employee;

public class GettingEmployeeDetails 
{
	
	public static void main(String[] args) 
	{
		Employee e1[]=null;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number of employees");
		int n = sc.nextInt();
		e1=new Employee[n];
		FileOutputStream fos = null;
		ObjectOutputStream oos = null;
		FileInputStream fis = null;
		ObjectInputStream ois = null;
		
		for(int i=0;i<n;i++)
		{
			e1[i]= new Employee();
			System.out.println("Enter Emp Id");
			int eid= sc.nextInt();
			System.out.println("Enter Emp Name");
			String enm= sc.next();
			System.out.println("Enter Emp Salary");
			double  esl= sc.nextDouble();
			System.out.println("Enter Emp insurance Scheme");
			String eis= sc.next();
			System.out.println("Enter Emp Designation");
			String ed= sc.next();
			e1[i]= new Employee(eid,enm,esl,eis,ed);
		}
		
		try 
		{

			fos = new  FileOutputStream("EmpObjs1.obj");
			oos = new ObjectOutputStream(fos);
			for(int i=0;i<n;i++)
			{
			oos.writeObject(e1[i]);
			}
			System.out.println("Emp e1 is written in the file");
			
			fis = new FileInputStream("EmpObjs1.obj");
			ois= new ObjectInputStream(fis);
			for (int i = 0; i < n; i++) 
			{
				Employee ee= (Employee)ois.readObject();
				System.out.println("Emp info from File: "+ ee);	
			}	
		} 
	
		catch (ClassNotFoundException | IOException e) 
		{
			
			e.printStackTrace();
		}
	
	}

}
