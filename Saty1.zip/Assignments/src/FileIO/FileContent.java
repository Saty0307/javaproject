package FileIO;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileContent 
{

	public static void main(String[] args) 
	{
		File myfile = new File("D:\\Satyam Kashmiri\\Assignments\\Input.txt");
		FileReader fr =null;
		FileWriter fw = null;
		BufferedReader br =null;
		BufferedWriter bw = null;
		StringBuilder sb= null;
		try 
		{
			fr = new FileReader(myfile);
			br= new BufferedReader(fr);
			fw = new FileWriter("Output.txt");
			bw = new BufferedWriter(fw);
			String line = br.readLine();
			sb= new StringBuilder();
			while(line!=null)
			{
				sb.append(line);
				line= br.readLine();
			}
			sb =sb.reverse();
			String rev = new String(sb);
			while(rev!=null)
			 {
				 System.out.println(rev);
				 bw.write(rev);
				 bw.flush();// will write the data into file.
				 rev= br.readLine();
			 }
			
		} 
		catch (IOException e) 
		{
			
			e.printStackTrace();
		}
		

	}

}
