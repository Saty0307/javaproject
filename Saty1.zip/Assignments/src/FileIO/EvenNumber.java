package FileIO;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class EvenNumber 
{

	public static void main(String[] args) 
	{

		File file = null;
		

		try 
		{
			 file = new File("number.txt");
			Scanner sc = new Scanner(file);
			String str= sc.nextLine();
			String arr[] = str.split(",");
			for (int i = 0; i < arr.length; i++) 
			{
				if(Integer.parseInt(arr[i])%2==0)
				{
					System.out.print(arr[i]);
				}
			}
			

		} 
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
		}
	}

}
