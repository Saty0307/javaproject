package FileIO;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Properties;
import java.util.Scanner;

public class PersonProps 
{

	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Emp Id");
		String eid= sc.next();
		System.out.println("Enter Emp Name");
		String enm= sc.next();
		System.out.println("Enter Emp Salary");
		String esl= sc.next();
		
		FileInputStream fis = null;
		FileOutputStream fos = null;
		Properties myInfo= null;
		
		try 
		{	
			fos = new  FileOutputStream("PersonProps.properties");
			myInfo = new Properties();
			myInfo.setProperty("id", eid);
			myInfo.setProperty("Name", enm);
			myInfo.setProperty("Salary", esl);
			myInfo.store(fos, "Personal Details");
			System.out.println("Details are written in the file");
			
			
			fis = new FileInputStream("PersonProps.properties");
			myInfo.load(fis);
			String uid= myInfo.getProperty("id");
			String unm= myInfo.getProperty("Name");
			String usl= myInfo.getProperty("Salary");
			System.out.println("Personal Details :" + "ID : " + uid + " Name : " + unm + 
					" Salary : " + esl);
		} 
		catch (IOException e) 
		{
				
				e.printStackTrace();
		}

	}

}
