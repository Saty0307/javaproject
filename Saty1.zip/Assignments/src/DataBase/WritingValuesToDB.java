package DataBase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;


public class WritingValuesToDB
{
	public void addingValues(int id,String name,double salary,String Scheme, String Desgn)
	{
		Double dob = new Double(salary);
		int sal= dob.intValue();
		Connection con = null;
		Scanner sc = new Scanner(System.in);
		String insertQry = "INSERT INTO Details values(?,?,?,?,?)";


		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:ORCL11G",
					"lab1btrg33","lab1boracle");

			PreparedStatement pst= con.prepareStatement(insertQry);
			pst.setInt(1,id);
			pst.setString(2,name);
			pst.setDouble(3,sal);
			pst.setString(4, Scheme);
			pst.setString(5, Desgn);
			pst.executeUpdate();
			System.out.println("data is insereted in the table");
		}
		catch (ClassNotFoundException |SQLException e) 
		{
			e.printStackTrace();
		}
	}
}
