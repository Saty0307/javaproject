package com.cg.eis.service;

import com.cg.eis.bean.Employee;

public interface EmployeeService 
{

	void computeScheme(Employee e1);

	void display(Employee e1);
    
}
