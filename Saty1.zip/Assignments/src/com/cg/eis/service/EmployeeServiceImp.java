package com.cg.eis.service;

import com.cg.eis.bean.Employee;

public class EmployeeServiceImp implements EmployeeService

{ 	
	
	@Override
	public void computeScheme(Employee e1)
	{	
		double sal;		
		sal= e1.getSalary();
		if(sal>5000 && sal < 20000)
		{
			e1.setInsuranceScheme("Scheme C");
			e1.setDesignation("System Associate");
		}
		else if(sal>=20000 && sal < 40000)
		{
			e1.setInsuranceScheme("Scheme B");
			e1.setDesignation("Programmer");
		}
		else if(sal>=40000)
		{
			e1.setInsuranceScheme("Scheme A");
			e1.setDesignation("Manager");
		}
		else if(sal<5000)
		{
			e1.setInsuranceScheme("No Scheme");
			e1.setDesignation("Clerk");
		}
}

	@Override
	public void display(Employee e1) {
		System.out.println(e1);
		
	}


}
