package com.cg.eis.pl;

import java.sql.SQLException;
import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.bean.HashMapEmployeeDetails;
import com.cg.eis.service.EmployeeServiceImp;

import DataBase.WritingValuesToDB;


public class Services {

	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		Employee Arr= null;
		WritingValuesToDB  db= new WritingValuesToDB(); 
		EmployeeServiceImp esi = new EmployeeServiceImp();
		//HashMapEmployeeDetails hmed= new HashMapEmployeeDetails();
		System.out.println("Enter no. of employees");
		int n= sc.nextInt();
		for(int i=0;i<n;i++)
		{
			Arr= new Employee();
			System.out.println("Enter your Details");
			System.out.println("Enter Employee Id");
			int id= sc.nextInt();
			System.out.println("Enter Employee Name");
			String name= sc.next();
			System.out.println("Enter Employee Salary");
			float sal= sc.nextFloat();
		
			Arr.setId(id);
			Arr.setSalary(sal);
			Arr.setName(name);
			esi.computeScheme(Arr);	
			db.addingValues(Arr.getId(), Arr.getName(), Arr.getSalary(), 
				Arr.getInsuranceScheme(),Arr.getDesignation());	//addding values to database	
			//hmed.addValues(Arr.getInsuranceScheme(),Arr);
			
			//esi.display(Arr);
		}
		}
		/*sc.nextLine();
		//System.out.println("Enter the Scheme of employee");
		//String scheme=sc.nextLine();
		//hmed.schemeFunt(scheme);
		
		//System.out.println("Enter the Scheme of employee to delete that employee");
		//String sch=sc.nextLine();
		//hmed.deleteEmployee(sch);
		
		//hmed.sort();
		
		
		sc.close();*/

	}
