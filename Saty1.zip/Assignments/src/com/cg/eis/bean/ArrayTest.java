package com.cg.eis.bean;

import java.util.Scanner;

public class ArrayTest 
{
	public static void main(String[] args) 
	{
		String A[] = new String[5];
		String temp;
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter Your Products");
		for (int i=0;i<A.length;i++) 
		{
			A[i]= sc.nextLine();
		}
		for(int i=0;i<A.length;i++)
		{
			for(int j=i+1;j<A.length;j++)
			{
				if (A[i].compareTo(A[j])>0) 
                {
                    temp = A[i];
                    A[i] = A[j];
                    A[j] = temp;
                }
			}
		}
		for(int i=0;i<A.length;i++)
		{
			System.out.println(A[i]);
		}
	}
	/*TreeSet<String> ts = new TreeSet<String>();
	
	String s1= new String("Satyam");
	String s2= new String("KIKI");
	String s3= new String("Jeery");
	String s4= new String("ola");
	String s5= new String("zebra");
	
	ts.add(s1);
	ts.add(s2);
	ts.add(s3);
	ts.add(s4);
	ts.add(s5);
	
	Iterator<String> si = ts.iterator();
	System.out.println("Sorted order is :");
	while(si.hasNext())
	{
		String s=si.next();
		System.out.println(s);
	}*/
}
