package com.cg.eis.bean;

import java.util.ArrayList;
import java.util.Collections;

public class ArrayListSorting 
{
	public static void main(String[] args) 
	{
		ArrayList<String> al = new ArrayList<String>();
		
		String s1= new String("Satyam");
		String s2= new String("KIKI");
		String s3= new String("Jerry");
		String s4= new String("ola");
		String s5= new String("zebra");
		
		al.add(s1);
		al.add(s2);
		al.add(s3);
		al.add(s4);
		al.add(s5);
		
		Collections.sort(al);
		System.out.println("Sorted order is :");
		for(String st:al)
		{
			System.out.println(st);
		}
	}

}
