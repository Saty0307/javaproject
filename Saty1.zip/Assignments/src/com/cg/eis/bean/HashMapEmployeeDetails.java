package com.cg.eis.bean;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.TreeSet;

import com.cg.eis.bean.Employee;

public class HashMapEmployeeDetails 
{

	
		
		HashMap<String,Employee> list = new HashMap<String,Employee>();
		
		public void  addValues(String schm, Employee e)
		{
			list.put(schm,e);
			//display();
		}
		public void schemeFunt(String sch)
		{
			System.out.println(list.get(sch));
		}
		
		public void deleteEmployee(String id)	
		{
			if(list.containsKey(id))
			{
				list.remove(id);
				System.out.println("User Deleted");
			}
			else
			{
				System.out.println("User Not found");
				
			}
		}
		
		
		public void sort()
		{
			TreeSet<Employee> ts = new TreeSet<Employee>();
			
			Collection<Employee> vset =list.values();
			
			Iterator<Employee> itv = vset.iterator();
			
			
			for(Employee value:vset)
			{
				ts.add(value);
				System.out.println(" : " + value);
			}
			
		}
		

	
}
