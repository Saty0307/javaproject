package testCase;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class DateTestCase 
{			

	Date d= new Date(23,05,1995);
	@Test
	public void testDay()
	{
		System.out.println("Day :" + d.getDay());
		
		assertEquals(23,d.getDay());
	}
	@Test
	public void testMonth()
	{
		System.out.println("Month :" + d.getMonth());
		
		assertEquals(5,d.getMonth());
	}
	@Test
	public void testyear()
	{
		System.out.println("Year :" + d.getYear());
		
		assertEquals(1995,d.getYear());
	}
	@Test
	public void testdate()
	{
		System.out.println("Date :" + d.toString());
		
		assertEquals("Date is 23/5/1995",d.toString());
	}
}
