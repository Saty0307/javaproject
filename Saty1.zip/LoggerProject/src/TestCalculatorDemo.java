import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class TestCalculatorDemo {

	public static void main(String[] args) 
	{
		Logger myLogger = Logger.getLogger(TestCalculatorDemo.class);
		PropertyConfigurator.configure("log4j.properties");
		Scanner sc=new Scanner (System.in);
		myLogger.debug("This is debug message");
		myLogger.warn("This is warn message");
		myLogger.fatal("This is fatal Message");
		System.out.println("Enter a");
		int a=sc.nextInt();
		myLogger.info("User Entered a : " + a);
		System.out.println("Enter b");
		int  b= sc.nextInt();
		myLogger.info("User Entered b : " + b);
		int c=0;
		try
		{
			c=a/b;
			System.out.println("c=" + c);
			myLogger.info("c =" + c);
			
		}
		catch(ArithmeticException ae)
		{
			myLogger.error(ae.getMessage());
			ae.printStackTrace();
		}

	}

}
